#ifndef SKEL_XML_OUTPUT_H
#define SKEL_XML_OUTPUT_H

int skel_write_coarse_xml_data (double open_time, double write_time, double close_time, double total_time);

#endif
